# -*- coding: utf-8 -*-
#
# Convert all audio files in current folder to mp3 with ffmpeg                                 
#                                                                             
# Author: (c) Hagen Jaeger                      April 2016 - January 2018  
# MIT Release: Nov. 2017, License see end of file                              
#--------------------------------------------------------------------------

import os
from subprocess import call

cwd = os.getcwd()
mp3Path = os.path.join(cwd, 'mp3')

if not os.path.exists(mp3Path):
    os.mkdir(mp3Path)
    
wavFileList = [file for file in os.listdir(cwd) if '.wav' in file]

for file in wavFileList:
    command = 'ffmpeg -i '+os.path.join(cwd, file)+' -vn -ar 44100 -ac 2 -ab 192k -f mp3 ' + os.path.join(mp3Path, file.replace('.wav','.mp3'))
    call(command, shell=True)       
        
#--------------------Licence ---------------------------------------------
# Copyright (c) 2012-2018 Hagen Jaeger                           
#
# Permission is hereby granted, free of charge, to any person obtaining a 
# copy of this software and associated documentation files (the "Software"), 
# to deal in the Software without restriction, including without limitation 
# the rights to use, copy, modify, merge, publish, distribute, sublicense, 
# and/or sell copies of the Software, and to permit persons to whom the 
# Software is furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included 
# in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS 
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
# THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING 
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
# DEALINGS IN THE SOFTWARE. 