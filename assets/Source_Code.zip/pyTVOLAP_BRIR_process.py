# -*- coding: utf-8 -*-
#
# This script evaluates TVOLAP against other known Real time procedures
# regarding their switching behaviour when convolving TU Berlin KEMAR HRTFs
# with a sinusodial signal.
# Author: Hagen Jaeger (c) TGM @ Jade Hochschule applied licence see EOF
# Version History:
# Ver. 0.1 initial create (empty) 22.01.2017 (HJ)
# Ver. 0.2 debugged and tested manually 23.01.2017 (HJ)
#--------------------------------------------------------------------------

import numpy as np
from pyOLA import OLA
from pyOLS import OLS
from pyWOLA import WOLA
from pyTVOLAP import TVOLAP
import time
import soundfile as sf

if __name__ == '__main__':
    
    audioFileStr = 'cello_C3_phrase_cresc-decresc_arco-normal.wav'
    
    ### read HRIR responses for 0 and 90deg from TU berlin Kemar ###
    
    IR = np.fromfile('SBSBRIR_x0y0.bin', dtype='float')
    IR = np.reshape(IR, (32768,2,360)).T
    #IR = IR[:,:,:8192]
    lenIR = np.size(IR,2)
    hopSizeIR = int(45)
    startOffsetIR = int(0)
    
    ### read speech input signal, declare some variables ###
    
    inSig, fs = sf.read(audioFileStr)
    blockLen = 2**(int(np.log2(lenIR-1))+1)
    numChans = np.size(IR,1)
    tmpRoundLen = 2**(int(np.log2(lenIR-1))+1)
    numSampsPerChan = int(np.round(np.size(inSig,0)/tmpRoundLen)*tmpRoundLen)
    numIR = np.size(IR,0)
    numBlocks = int(numSampsPerChan/blockLen)
    numBlocksTillSwitch = 1
    
    if inSig.ndim == 1:
        inSig = np.repeat(inSig[np.newaxis,:], numChans, axis=0)
    else:
        inSig = inSig.T
        
    inSig = inSig[:,:numSampsPerChan]
    
    numSampsPerChan = np.size(inSig,1)
    
    ### calculate outputs via standard Overlap Add ###
    
    OLAinst = OLA(IR)
    outSig = np.copy(inSig)
    actIR = startOffsetIR
    OLAinst.setImpResp(actIR)
    start_time = time.time()
    for blockCnt in np.arange(numBlocks):
        tmpIdxLo = int(blockCnt*blockLen)
        tmpIdxHi = tmpIdxLo+blockLen
        outSig[:,tmpIdxLo:tmpIdxHi] = OLAinst.process(inSig[:,tmpIdxLo:tmpIdxHi])
        actIR = (actIR+hopSizeIR)%numIR
        OLAinst.setImpResp(actIR)
    print(str(time.time() - start_time)+ ' seconds for OLA')
    
    sf.write(audioFileStr.replace('.wav', '_OLA.wav'), outSig.T*3, fs)
            
    ### calculate outputs via standard Overlap Save ###
    
    blockLen = 2**(int(np.log2(lenIR-1))+1)
    numBlocks = int(numSampsPerChan/blockLen)
    numBlocksTillSwitch = 1
    
    OLSinst = OLS(IR)
    outSig = np.copy(inSig)
    actIR = startOffsetIR
    OLSinst.setImpResp(actIR)
    start_time = time.time()
    for blockCnt in np.arange(numBlocks):
        tmpIdxLo = int(blockCnt*blockLen)
        tmpIdxHi = tmpIdxLo+blockLen
        outSig[:,tmpIdxLo:tmpIdxHi] = OLSinst.process(inSig[:,tmpIdxLo:tmpIdxHi])
        actIR = (actIR+hopSizeIR)%numIR
        OLSinst.setImpResp(actIR)
    print(str(time.time() - start_time)+ ' seconds for OLS')
    
    sf.write(audioFileStr.replace('.wav', '_OLS.wav'), outSig.T*3, fs)
    
    ### calculate outputs via standard weighted overlap add RH ###
    
    blockLen = 2**(int(np.log2(lenIR-1))+1)
    numBlocks = int(numSampsPerChan/blockLen)
    numBlocksTillSwitch = 1
    
    WOLAinst = WOLA(IR, False)
    outSig = np.copy(inSig)
    actIR = startOffsetIR
    WOLAinst.setImpResp(actIR)
    start_time = time.time()
    for blockCnt in np.arange(numBlocks):
        tmpIdxLo = int(blockCnt*blockLen)
        tmpIdxHi = tmpIdxLo+blockLen
        outSig[:,tmpIdxLo:tmpIdxHi] = WOLAinst.process(inSig[:,tmpIdxLo:tmpIdxHi])
        actIR = (actIR+hopSizeIR)%numIR
        WOLAinst.setImpResp(actIR)
    print(str(time.time() - start_time)+ ' seconds for WOLA RH')
    
    sf.write(audioFileStr.replace('.wav', '_WOLA.wav'), outSig.T*3, fs)
    
    ### calculate output via TVOLAP procedure to compare it ###
    
    blockLen = 1024
    numBlocks = int(numSampsPerChan/blockLen)
    numBlocksTillSwitch = 2**(int(np.log2(lenIR-1))+1)/blockLen
    
    TVOLAPinst = TVOLAP(IR, blockLen)
    outSig = np.copy(inSig)
    actIR = startOffsetIR
    TVOLAPinst.setImpResp(actIR)
    start_time = time.time()
    for blockCnt in np.arange(numBlocks):
        tmpIdxLo = int(blockCnt*blockLen)
        tmpIdxHi = tmpIdxLo+blockLen
        outSig[:,tmpIdxLo:tmpIdxHi] = TVOLAPinst.process(inSig[:,tmpIdxLo:tmpIdxHi])
        if blockCnt%numBlocksTillSwitch == numBlocksTillSwitch-1:
            actIR = (actIR+hopSizeIR)%numIR
            TVOLAPinst.setImpResp(actIR)
    print(str(time.time() - start_time)+ ' seconds for TVOLAP')
    
    sf.write(audioFileStr.replace('.wav', '_TVOLAP.wav'), outSig.T*3, fs)
    
#--------------------Licence ---------------------------------------------
# Copyright (c) 2012-2018 Hagen Jaeger                           
#
# Permission is hereby granted, free of charge, to any person obtaining a 
# copy of this software and associated documentation files (the "Software"), 
# to deal in the Software without restriction, including without limitation 
# the rights to use, copy, modify, merge, publish, distribute, sublicense, 
# and/or sell copies of the Software, and to permit persons to whom the 
# Software is furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included 
# in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS 
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
# THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING 
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
# DEALINGS IN THE SOFTWARE. 